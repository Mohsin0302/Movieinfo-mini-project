﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace ClassLibraryDAL
{
    public class DB_Helper
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection con = new SqlConnection("Data Source=MAANI\\SQL;Initial Catalog=MoiveInfo;Integrated Security=True");
            return con;
        }
    }
}
