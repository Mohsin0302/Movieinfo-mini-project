﻿using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using ClassLibraryModel;
using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using Microsoft.AspNetCore.Http;


namespace ClassLibraryDAL
{
    public class AddMovie
    {
        public string MovieName;
        public string MovieDescription;
        public string LeadCharacter;
        public string Director;

        public static void StoreDataInDatabase(string connectionString, string moviename, string moviedesc, string leadcharacterm,string director, string imageUrl)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var query = "INSERT INTO Movies (MovieName, MovieDesc,LeadCharacterM,Director, ImageUrl) VALUES (@moviename, @moviedesc, @leadcharacterm,@director,@imageUrl)";
                using (var command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@moviename", moviename);
                    command.Parameters.AddWithValue("@moviedesc", moviedesc);
                    command.Parameters.AddWithValue("@leadcharacterm", leadcharacterm);
                    command.Parameters.AddWithValue("@director", director);
                    command.Parameters.AddWithValue("@imageUrl", imageUrl);
                    command.ExecuteNonQuery();
                }
            }
        }


        public static async Task<string> UploadImageToGoogleCloudStorage(string projectId, string bucketName, IFormFile imageFile)
        {
            var credential = GoogleCredential.FromFile("C:\\Users\\HP ELITE BOOK\\Downloads\\mystorage007k-b08d353b66bb.json");
            var storage = StorageClient.Create(credential);

            var imageObjectName = imageFile.FileName;
            using (var memoryStream = new MemoryStream())
            {
                await imageFile.CopyToAsync(memoryStream);
                memoryStream.Position = 0;

                var imageObject = await storage.UploadObjectAsync(bucketName, imageObjectName, null, memoryStream);

                return imageObject.MediaLink;
            }
        }
        public static int Deletedata(int id)
        {
            SqlConnection conn = DB_Helper.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("Sp_deleteMovie", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MovieId", id);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            return i;
        }
    }
}
