﻿using ClassLibraryModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryDAL
{
    public class GetMovies
    {
        

        
        public List<MoviesModel> GetMoviesFromDatabase()
        {
            var Movies = new List<MoviesModel>();

            using (var connection = new SqlConnection("Data Source=MAANI\\SQL;Initial Catalog=MoiveInfo;Integrated Security=True"))
            {
                connection.Open();

                var query = "SELECT MovieId, MovieName, MovieDesc, LeadCharacterM,Director, ImageUrl FROM Movies";
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var movie= new MoviesModel
                        {
                            Id=reader.GetInt32(0),
                            MovieName = reader.GetString(1),
                            MovieDesc = reader.GetString(2),
                            LeadCharacterM = reader.GetString(3),
                            Director=reader.GetString(4),
                            ImageUrl=reader.GetString(5),   
                        };

                        Movies.Add(movie);
                    }
                }
            }

            return Movies;
        }
    }
}
