﻿using ClassLibraryDAL;
using ClassLibraryModel;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MoviesDAL
{
    public class UserDAL
    {
        public static int SaveData(User user)
        {
            SqlConnection conn = DB_Helper.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("sp_SaveUsers", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Username", user.Username);
            cmd.Parameters.AddWithValue("@Password", user.Password);
            cmd.Parameters.AddWithValue("@Contact", user.Contact);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            return i;
        }
        public static List<User> GetData()
        {
            SqlConnection con = DB_Helper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("Sp_GetUsers", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataReader sdr = cmd.ExecuteReader();
            List<User> UsersList = new List<User>();
            while (sdr.Read())
            {
                User Smodel = new User();
                Smodel.Username = sdr["Username"].ToString();
                Smodel.Password = sdr["Password"].ToString();
                Smodel.Contact = int.Parse(sdr["Contact"].ToString());
                Smodel.UserId= int.Parse(sdr["UserId"].ToString()); 
                UsersList.Add(Smodel);
            }
            con.Close();
            return UsersList;
        }
        public static int Deletedata(User userid)
        {
            SqlConnection conn = DB_Helper.GetConnection();
            conn.Open();
            SqlCommand cmd = new SqlCommand("Sp_DeleteUser", conn);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserId", userid);
            int i = cmd.ExecuteNonQuery();
            conn.Close();
            return i;
        }
    }
}
