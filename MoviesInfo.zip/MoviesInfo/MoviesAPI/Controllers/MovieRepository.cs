﻿using ClassLibraryDAL;

namespace MoviesAPI.Controllers
{
    internal class MovieRepository
    {
        private string connectionString;

        public MovieRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }

        internal AddMovie GetMovieById(int id)
        {
            throw new NotImplementedException();
        }
    }
}