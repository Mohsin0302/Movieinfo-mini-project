﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ClassLibraryModel;
using System.IO;
using System.Threading.Tasks;
using System.Data.SqlClient;
using ClassLibraryDAL;


namespace MoviesAPI.Controllers
{
    [Route("api/Movies")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly object _context;

        [HttpPost]
        [Route("uploadmovie")]
        public async Task<IActionResult> UploadImage([FromForm] IFormFile imageFile, [FromForm] string moviename, [FromForm] string moviedesc,[FromForm] string leadcharacterm,[FromForm] string director)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                var imageUrl = await AddMovie.UploadImageToGoogleCloudStorage("mystorage007k", "my-bucket-007k", imageFile);
                AddMovie.StoreDataInDatabase("Data Source=MAANI\\SQL;Initial Catalog=MoiveInfo;Integrated Security=True", moviename, moviedesc, leadcharacterm, director, imageUrl);

                return Ok("Uploaded.");
            }

            return BadRequest("No image file found.");
        }

         [HttpGet]
        public IActionResult Index()
        {
            var getMovies = new GetMovies(); // Instantiate the GetBlogs class
            var movies = getMovies.GetMoviesFromDatabase();
            return Ok(movies);
        }
       

        [HttpPut("{id}")]
        public IActionResult UpdateMovie(int id, [FromForm] IFormFile imageFile,[FromForm] string moviename, [FromForm] string moviedesc, [FromForm] string leadcharacterm, [FromForm] string director)
        {
            // Update movie logic here using the provided parameters

            // First, check if the movie with the given ID exists in the database
            var movie = GetMovieByIdFromDatabase(id);
            if (movie == null)
            {
                return NotFound("Movie not found.");
            }

            // Update the movie details
            movie.MovieName = moviename;
            movie.MovieDescription = moviedesc;
            movie.LeadCharacter = leadcharacterm;
            movie.Director = director;
          

            // Save the updated movie back to the database
            UpdateMovieInDatabase(movie);

            return Ok("Movie updated successfully.");
        }

        private AddMovie GetMovieByIdFromDatabase(int id)
        {
            throw new NotImplementedException();
        }

        private void UpdateMovieInDatabase(AddMovie movie)
        {
            throw new NotImplementedException();
        }

        //[HttpPut("{id}")]
        //public async Task<IActionResult> PutUserModel(int id, MoviesModel moviesModel)
        //{
        //    if (id != moviesModel.Id)
        //    {
        //        return BadRequest();
        //    }

        //    _context.Entry(moviesModel).State = EntityState.Modified;

        //    try
        //    {
        //        await _context.SaveChangesAsync();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!UserModelExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return NoContent();
        //}

        //[HttpPut("{id}")]
        //public IActionResult UpdateMovie(int id, [FromForm] IFormFile imageFile, [FromForm] string moviename, [FromForm] string moviedesc, [FromForm] string leadcharacterm, [FromForm] string director)
        //{
        //    // Update movie logic here using the provided parameters
        //    // For example, you can use the id to identify the movie in the database and update its details

        //    return Ok("Movie updated successfully.");
        //}

        //[HttpDelete("{id}")]
        //public IActionResult DeleteMovie(int id)
        //{
        //    // Delete movie logic here using the provided id
        //    // For example, you can use the id to identify the movie in the database and delete it

        //    return Ok("Movie deleted successfully.");
        //}



    }
}
